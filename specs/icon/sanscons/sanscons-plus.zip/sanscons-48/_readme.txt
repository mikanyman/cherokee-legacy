Title : 	Sanscons-48
Designer : 	P.J. Onori
Email :		somerandomdude@somerandomdude.net
URL : 		http://www.somerandomdude.net/

Description :	A collection of 48x48 pixel icons for various subjects

Created : 	6/4/06


Use :		Consume and enjoy. Please make sure to show some love and be generous with the
		linkage if you decide to use them. 